# To actually have your app use this file, you need to RENAME the file to db_credentials.py
# You will find details about your CS340 database credentials on Canvas.

# the following will be used by the db_connector.py and
# in turn by all the Python code in this codebase to interact with the database

host = 'classmysql.engr.oregonstate.edu'  #DON'T CHANGE ME UNLESS THE INSTRUCTIONS SAY SO
user = 'cs340_sharmabh' #CHANGE ME
passwd = '1720' #CHANGE ME
db = 'cs340_sharmabh' #CHANGE ME
